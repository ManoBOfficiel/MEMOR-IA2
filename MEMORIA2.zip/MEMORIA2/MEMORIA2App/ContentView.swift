
import SwiftUI
import Foundation
import Combine

// MARK: - Memor'IA
// Création : Manuel Balverde, alias Mano-B
// Mano-B Company, Inc. — Tous droits réservés.
// Mano-B Company Éditions

// MARK: - Couleurs


enum MBC {
    static let teal = Color(red: 0.34, green: 0.22, blue: 0.16)
    static let ink = Color(red: 0.25, green: 0.18, blue: 0.14)
    static let muted = Color(red: 0.52, green: 0.44, blue: 0.38)
    static let bg = Color(red: 0.98, green: 0.96, blue: 0.92)
    static let card = Color.white
    static let gold = Color(red: 0.72, green: 0.53, blue: 0.36)
}

// MARK: - Modèle des souvenirs

struct Souvenir: Identifiable, Codable {
    var id: UUID = UUID()
    var nom: String
    var souvenir: String
    var date: Date = Date()
}

// MARK: - Stockage local corrigé

final class SouvenirStore: ObservableObject {
    @Published var souvenirs: [Souvenir] = []

    private let cle = "memorIA.souvenirs.v1"

    init() {
        if let data = UserDefaults.standard.data(forKey: cle),
           let resultat = try? JSONDecoder().decode(
               [Souvenir].self,
               from: data
           ) {
            self.souvenirs = resultat
        }
    }

    private func sauvegarder() {
        guard let data = try? JSONEncoder().encode(souvenirs) else {
            return
        }

        UserDefaults.standard.set(data, forKey: cle)
    }

    func ajouter(nom: String, texte: String) {
        let nomNettoye = nom.trimmingCharacters(
            in: .whitespacesAndNewlines
        )
        let texteNettoye = texte.trimmingCharacters(
            in: .whitespacesAndNewlines
        )

        guard !nomNettoye.isEmpty,
              !texteNettoye.isEmpty else {
            return
        }

        let nouveau = Souvenir(
            nom: nomNettoye,
            souvenir: texteNettoye
        )

        souvenirs.insert(nouveau, at: 0)
        sauvegarder()
    }

    func supprimer(_ souvenir: Souvenir) {
        souvenirs.removeAll { $0.id == souvenir.id }
        sauvegarder()
    }
}

// MARK: - Application

@main
struct MemorIAApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

// MARK: - Accueil

struct ContentView: View {
    @StateObject private var store = SouvenirStore()
    @State private var afficherAjout = false
    @State private var recherche = ""

    private var souvenirsFiltres: [Souvenir] {
        guard !recherche.isEmpty else {
            return store.souvenirs
        }

        return store.souvenirs.filter {
            $0.nom.localizedCaseInsensitiveContains(recherche)
            || $0.souvenir.localizedCaseInsensitiveContains(recherche)
        }
    }

    var body: some View {
        NavigationStack {
            ZStack {
                MBC.bg.ignoresSafeArea()

                ScrollView {
                    VStack(alignment: .leading, spacing: 22) {
                        entete
                        carteBienvenue
                        rechercheBarre

                        HStack {
                            Text("Mon carnet de souvenirs")
                                .font(.system(size: 21, weight: .bold))
                                .foregroundStyle(MBC.ink)

                            Spacer()

                            Text("\(store.souvenirs.count)")
                                .font(.system(size: 14, weight: .bold))
                                .foregroundStyle(MBC.teal)
                        }

                        if souvenirsFiltres.isEmpty {
                            vueVide
                        } else {
                            LazyVStack(spacing: 12) {
                                ForEach(souvenirsFiltres) { item in
                                    NavigationLink {
                                        DetailSouvenirView(
                                            souvenir: item,
                                            store: store
                                        )
                                    } label: {
                                        carteSouvenir(item)
                                    }
                                    .buttonStyle(.plain)
                                }
                            }
                        }

                        piedDePage
                    }
                    .padding(20)
                    .frame(maxWidth: 650)
                    .frame(maxWidth: .infinity)
                }
            }
            .toolbar(.hidden, for: .navigationBar)
            .sheet(isPresented: $afficherAjout) {
                AjouterSouvenirView(store: store)
            }
        }
        .tint(MBC.teal)
    }

    private var entete: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 17)
                    .fill(MBC.teal)
                    .frame(width: 58, height: 58)

                Image(systemName: "heart.text.clipboard.fill")
                    .font(.system(size: 27))
                    .foregroundStyle(.white)
            }

            VStack(alignment: .leading, spacing: 4) {
                Text("Memor’IA")
                    .font(.system(size: 29, weight: .bold))
                    .foregroundStyle(MBC.ink)

                Text("Les souvenirs restent vivants")
                    .font(.system(size: 13))
                    .foregroundStyle(MBC.muted)
            }

            Spacer()

            Button {
                afficherAjout = true
            } label: {
                Image(systemName: "plus")
                    .font(.system(size: 19, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 46, height: 46)
                    .background(MBC.teal)
                    .clipShape(Circle())
            }
            .accessibilityLabel("Ajouter un souvenir")
        }
        .padding(.top, 8)
    }

    private var carteBienvenue: some View {
        VStack(alignment: .leading, spacing: 13) {
            Image(systemName: "sparkles")
                .font(.system(size: 28))
                .foregroundStyle(MBC.gold)

            Text("Chaque souvenir raconte une histoire.")
                .font(.system(size: 25, weight: .bold, design: .serif))
                .foregroundStyle(.white)

            Text("Conservez les instants précieux, les mots qui comptent et les histoires de ceux que vous aimez.")
                .font(.system(size: 15))
                .foregroundStyle(.white.opacity(0.88))
                .fixedSize(horizontal: false, vertical: true)

            Button {
                afficherAjout = true
            } label: {
                HStack {
                    Text("Créer un souvenir")
                    Image(systemName: "arrow.right")
                }
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(MBC.ink)
                .padding(.horizontal, 18)
                .padding(.vertical, 12)
                .background(.white)
                .clipShape(Capsule())
            }
            .padding(.top, 4)
        }
        .padding(23)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background {
            LinearGradient(
                colors: [
                    MBC.teal,
                    Color(red: 0.12, green: 0.31, blue: 0.34)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        }
        .clipShape(RoundedRectangle(cornerRadius: 25))
    }

    private var rechercheBarre: some View {
        HStack(spacing: 10) {
            Image(systemName: "magnifyingglass")
                .foregroundStyle(MBC.muted)

            TextField("Rechercher un souvenir...", text: $recherche)
                .font(.system(size: 15))
        }
        .padding(15)
        .background(MBC.card)
        .clipShape(RoundedRectangle(cornerRadius: 15))
    }

    private func carteSouvenir(_ item: Souvenir) -> some View {
        HStack(alignment: .top, spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 14)
                    .fill(MBC.teal.opacity(0.10))
                    .frame(width: 53, height: 53)

                Image(systemName: "heart.fill")
                    .font(.system(size: 21))
                    .foregroundStyle(MBC.teal)
            }

            VStack(alignment: .leading, spacing: 7) {
                Text(item.nom)
                    .font(.system(size: 17, weight: .bold))
                    .foregroundStyle(MBC.ink)

                Text(item.souvenir)
                    .font(.system(size: 14))
                    .foregroundStyle(MBC.muted)
                    .lineLimit(2)
                    .multilineTextAlignment(.leading)

                Text(item.date.formatted(
                    date: .abbreviated,
                    time: .omitted
                ))
                .font(.system(size: 12))
                .foregroundStyle(MBC.teal)
            }

            Spacer(minLength: 0)

            Image(systemName: "chevron.right")
                .font(.system(size: 12, weight: .bold))
                .foregroundStyle(MBC.muted)
                .padding(.top, 5)
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(MBC.card)
        .clipShape(RoundedRectangle(cornerRadius: 19))
    }

    private var vueVide: some View {
        VStack(spacing: 13) {
            Image(systemName: "book.closed")
                .font(.system(size: 36))
                .foregroundStyle(MBC.teal.opacity(0.7))

            Text(
                recherche.isEmpty
                ? "Votre histoire commence ici"
                : "Aucun souvenir trouvé"
            )
            .font(.system(size: 18, weight: .semibold))
            .foregroundStyle(MBC.ink)

            Text(
                recherche.isEmpty
                ? "Ajoutez votre premier souvenir pour commencer votre carnet."
                : "Essayez un autre nom ou un autre mot."
            )
            .font(.system(size: 14))
            .foregroundStyle(MBC.muted)
            .multilineTextAlignment(.center)

            if recherche.isEmpty {
                Button("Ajouter mon premier souvenir") {
                    afficherAjout = true
                }
                .buttonStyle(.borderedProminent)
                .tint(MBC.teal)
            }
        }
        .frame(maxWidth: .infinity)
        .padding(28)
        .background(MBC.card)
        .clipShape(RoundedRectangle(cornerRadius: 20))
    }

    private var piedDePage: some View {
        VStack(spacing: 6) {
            Image(systemName: "heart.fill")
                .foregroundStyle(MBC.teal)

            Text("Memor’IA")
                .font(.system(size: 14, weight: .bold))
                .foregroundStyle(MBC.ink)

            Text("Création de Manuel Balverde, alias Mano-B")
                .font(.system(size: 11))
                .foregroundStyle(MBC.muted)

            Text("Mano-B Company, Inc. • Mano-B Company Éditions")
                .font(.system(size: 10))
                .foregroundStyle(MBC.muted)

            Text("Tous droits réservés.")
                .font(.system(size: 10))
                .foregroundStyle(MBC.muted)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 22)
    }
}

// MARK: - Ajouter un souvenir

struct AjouterSouvenirView: View {
    @ObservedObject var store: SouvenirStore
    @Environment(\.dismiss) private var dismiss

    @State private var nom = ""
    @State private var texte = ""

    private var formulaireValide: Bool {
        !nom.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        && !texte.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    var body: some View {
        NavigationStack {
            ZStack {
                MBC.bg.ignoresSafeArea()

                Form {
                    Section {
                        TextField("Nom ou titre du souvenir", text: $nom)

                        VStack(alignment: .leading, spacing: 8) {
                            Text("Racontez votre souvenir")
                                .font(.system(size: 14, weight: .medium))
                                .foregroundStyle(MBC.teal)

                            TextEditor(text: $texte)
                                .frame(minHeight: 180)
                        }
                    } header: {
                        Text("Un souvenir précieux")
                    } footer: {
                        Text("Ces informations sont enregistrées localement sur cet appareil.")
                    }

                    Section {
                        Button {
                            enregistrer()
                        } label: {
                            HStack {
                                Spacer()
                                Image(systemName: "heart.fill")
                                Text("Enregistrer mon souvenir")
                                Spacer()
                            }
                            .font(.system(size: 16, weight: .semibold))
                        }
                        .disabled(!formulaireValide)
                    }
                }
                .scrollContentBackground(.hidden)
            }
            .navigationTitle("Nouveau souvenir")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Annuler") {
                        dismiss()
                    }
                }
            }
        }
        .tint(MBC.teal)
    }

    private func enregistrer() {
        guard formulaireValide else { return }

        store.ajouter(nom: nom, texte: texte)
        dismiss()
    }
}

// MARK: - Détail d'un souvenir

struct DetailSouvenirView: View {
    let souvenir: Souvenir
    @ObservedObject var store: SouvenirStore
    @Environment(\.dismiss) private var dismiss

    @State private var confirmerSuppression = false

    var body: some View {
        ZStack {
            MBC.bg.ignoresSafeArea()

            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 25)
                            .fill(MBC.teal.opacity(0.12))
                            .frame(height: 160)

                        Image(systemName: "heart.text.clipboard.fill")
                            .font(.system(size: 58))
                            .foregroundStyle(MBC.teal)
                    }

                    VStack(alignment: .leading, spacing: 12) {
                        Text(souvenir.nom)
                            .font(.system(
                                size: 29,
                                weight: .bold,
                                design: .serif
                            ))
                            .foregroundStyle(MBC.ink)

                        Label(
                            souvenir.date.formatted(
                                date: .long,
                                time: .omitted
                            ),
                            systemImage: "calendar"
                        )
                        .font(.system(size: 13))
                        .foregroundStyle(MBC.teal)

                        Divider()

                        Text(souvenir.souvenir)
                            .font(.system(size: 17))
                            .foregroundStyle(MBC.ink)
                            .lineSpacing(6)
                            .frame(
                                maxWidth: .infinity,
                                alignment: .leading
                            )
                    }
                    .padding(20)
                    .background(MBC.card)
                    .clipShape(RoundedRectangle(cornerRadius: 22))

                    Button(role: .destructive) {
                        confirmerSuppression = true
                    } label: {
                        Label(
                            "Supprimer ce souvenir",
                            systemImage: "trash"
                        )
                        .frame(maxWidth: .infinity)
                        .padding(14)
                    }
                    .buttonStyle(.bordered)
                    .confirmationDialog(
                        "Supprimer ce souvenir ?",
                        isPresented: $confirmerSuppression,
                        titleVisibility: .visible
                    ) {
                        Button("Supprimer", role: .destructive) {
                            store.supprimer(souvenir)
                            dismiss()
                        }

                        Button("Annuler", role: .cancel) {}
                    } message: {
                        Text("Cette action supprimera le souvenir enregistré sur cet appareil.")
                    }
                }
                .padding(20)
                .frame(maxWidth: 650)
                .frame(maxWidth: .infinity)
            }
        }
        .navigationTitle("Mon souvenir")
        .navigationBarTitleDisplayMode(.inline)
    }
}
